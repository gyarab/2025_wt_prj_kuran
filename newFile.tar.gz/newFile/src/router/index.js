import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import PrehledView from '../views/PrehledView.vue'
import SpravaView from '../views/SpravaView.vue'

const router = createRouter({
    history: createWebHistory(),
    routes: [
        { path: '/', name: 'home', component: HomeView },
        { path: '/prehled', name: 'prehled', component: PrehledView },
        { path: '/sprava', name: 'sprava', component: SpravaView },
    ]
})

export default router
