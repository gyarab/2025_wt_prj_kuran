<script setup>
import { ref, onMounted } from 'vue'

const nadpis = ref('Pára')

onMounted(() => {
    console.log('Frontend aplikace je připravena!')
})
</script>

<template>
  <h1>{{ nadpis }}</h1>
  <p>
    Komunitní databáze videoher inspirovaná Steamem. Tento frontend běží na Vue.js
    a je připraven na napojení na backend (Vite proxuje <code>/api</code> na Django).
  </p>
</template>
