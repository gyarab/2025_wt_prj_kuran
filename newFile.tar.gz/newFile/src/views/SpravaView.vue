<template>
  <h2>Správa</h2>
  <p>Administrace katalogu (přidávání, editace a mazání záznamů) — připravuje se.</p>
</template>
