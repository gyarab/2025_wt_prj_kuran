<script setup>
</script>

<template>
  <nav class="navbar">
    <div class="logo">PrjMachek</div>
    <ul class="nav-links">
      <li><RouterLink to="/">Domů</RouterLink></li>
      <li><RouterLink to="/prehled">Přehled</RouterLink></li>
      <li><RouterLink to="/sprava">Správa</RouterLink></li>
    </ul>
  </nav>
</template>

<style scoped>
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  color: white;
  padding: 10px 20px;
  border-radius: 8px;
}
.nav-links {
  list-style: none;
  display: flex;
  gap: 15px;
}
.nav-links a {
  color: white;
  text-decoration: none;
}
.nav-links a:hover {
  text-decoration: underline;
}
.nav-links a.router-link-active {
  font-weight: bold;
  text-decoration: underline;
}
</style>
